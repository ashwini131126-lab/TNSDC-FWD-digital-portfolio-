function checkAnswers() {

  let score = 0;

  // Correct answers

  let answers = {

    q1: "a",

    q2: "b",

    q3: "b"

  };

  for (let q in answers) {

    let selected = document.querySelector(`input[name=${q}]:checked`);

    if (selected && selected.value === answers[q]) {

      score++;

    }

  }

  document.getElementById("score").innerText =

    "Your Score: " + score + "/3 🎉";

}